import React, { Component } from 'react'
import Grid from '@material-ui/core/Grid'
import Art from './Art'

export default class Content extends Component {
  render() {
    return (
        <Grid item xs={12} sm={9}>
            <Grid container spacing={32}>
                <Art/>
                <Art/>
                <Art/>
                <Art/>
                <Art/>
                <Art/>                
            </Grid>
        </Grid>
    )
  }
}
