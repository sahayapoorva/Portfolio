import React, { Component } from 'react'
import Grid from '@material-ui/core/Grid'
import Typography from '@material-ui/core/Typography'

export default class Sidebar extends Component {
  render() {
    return (
        <Grid item xs={12} sm={3}>
            <Grid container>
                <Grid item xs={12}>
                    <img alt="avatar" src="https://pickaface.net/gallery/avatar/aament533c2880625b4.png" className="avatar"/>
                </Grid>
                <Grid item xs={12}>
                    <Typography title variant="h5" component="h2">
                        Stuti Sinha
                    </Typography>
                </Grid>                
                <Grid item xs={12}>
                    <Typography gutterBottom="true" variant="h7" component="h3">
                        LinkedIn
                    </Typography>
                </Grid>
                <Grid item xs={12}>
                    <Typography gutterBottom="true" variant="h7" component="h3">
                        Instagram
                    </Typography>
                </Grid>
                <Grid item xs={12}>
                    <Typography gutterBottom="true" variant="h7" component="h3">
                        Resume
                    </Typography>
                </Grid>
            </Grid>
        </Grid>
    )
  }
}
