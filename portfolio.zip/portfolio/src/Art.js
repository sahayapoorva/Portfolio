import React, { Component } from 'react'
import Card from '@material-ui/core/Card'
import CardContent from '@material-ui/core/CardContent'
import CardMedia from '@material-ui/core/CardMedia'
import Typography from '@material-ui/core/Typography'
import Grid from '@material-ui/core/Grid'

export default class Art extends Component {
  render() {
    return (
        <Grid item xs={12} sm={6} md={4}>
            <Card className="artCard">
                <CardMedia 
                    image="https://react.semantic-ui.com/images/avatar/large/matthew.png"
                    className="artMedia"
                />
                <CardContent>
                    <Typography gutterBottom variant="h5" component="h2">
                        Lizard
                    </Typography>
                    <Typography component="p">
                        Lizards are a widespread group of squamate reptiles, with over 6,000 species, ranging
                        across all continents except Antarctica
                    </Typography>
                </CardContent>
            </Card>
        </Grid>
    )
  }
}
