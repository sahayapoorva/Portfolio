import React, { Component } from 'react'
import './App.css'
import Grid from '@material-ui/core/Grid';
import Sidebar from './Sidebar'
import Content from './Content'

export default class App extends Component {
  render() {
    return (
      <div className="root">
        <Grid container spacing={24}>
          <Sidebar/>
          <Content/>
        </Grid>
      </div>
    )
  }
}
